// Resources
function showValue(x) {
	switch (x) {
		case 'dollars':
			document.getElementById(x).innerHTML = "$ " + dollars.toLocaleString(undefined, {
				maximumFractionDigits: 0
			});
			break;
		case 'workers':
			document.getElementById(x).innerHTML = availableWorkers;
			break;
		case 'parts':
			document.getElementById(x).innerHTML = availableParts.toLocaleString(undefined, {
				maximumFractionDigits: 0
			});
			break;
		default:
			console.log('nope');
	}
}
// Airplanes
function showAirplaneName(z) {
	document.getElementById("airplaneName" + z).textContent = airplanes[z].name;
}


function showProductionStage(z) {
	document.getElementById("myBar" + z).style = "width:" + airplanes[z].productionStage.toString() + "%";
}

function showQuantity(z) {
	document.getElementById("quantity" + z).innerHTML = airplanes[z].quantity;
}

function showWorkers(z) {
	document.getElementById("workers" + z).innerHTML = airplanes[z].workers;
}

function showPrice(z) {
	document.getElementById("price" + z).innerHTML = "$ " + airplanes[z].price.toLocaleString();
}

function showAirplaneAll() {
	for (let i = 0; i < 3; i++) {
		showAirplaneName(i);
		showProductionStage(i);
		showQuantity(i);
		showWorkers(i);
		showPrice(i);
	}
}

// Menu cards
// Menu cards -> Employees
function showEmployeesNumber(z) {
	document.getElementById("employee" + z).textContent = employees[z].number + " / " + employees[z].maxNumber;
}

function totalSalary() {
	let x = 0;
	for (let i = 0; i < employees.length; i++) {
		x += employees[i].salary * employees[i].number
	}
	return x;
}

function showEmployeesSalary(z) {
	document.getElementById("salary" + z).textContent = "$ " + employees[z].salary;
	document.getElementById("totalSalary" + z).textContent = "$ " + employees[z].salary * employees[z].number;
	document.getElementById("salarySummary__value").textContent = "$ " + totalSalary();
}

function showEmployeesAll() {
	for (let i = 0; i < 3; i++) {
		showEmployeesSalary(i);
		showEmployeesNumber(i);
	}
}
// Menu cards -> Parts
function showPartsItem(z) {
	document.getElementById("parts-flag" + z).src = parts[z].flag;
	document.getElementById("parts-company" + z).textContent = parts[z].company;
	document.getElementById("parts-time" + z).textContent = parts[z].time;
	document.getElementById("parts-risk" + z).textContent = parts[z].risk;
	document.getElementById("parts-price" + z).textContent = parts[z].price;
	document.getElementById("parts-stock" + z).textContent = parts[z].stock;
	document.getElementById("parts-total" + z).textContent = parts[z].price * parts[z].stock;
}

// 
function progresWork(z, y) {
	if ((y / 100) <= availableParts) {
		airplanes[z].productionStage += y / airplanes[z].parts;
		availableParts -= y / 100;
		showValue("parts");
		if (airplanes[z].productionStage >= 100) {
			availableParts += (airplanes[z].productionStage - 100) * airplanes[z].parts / 100;
			airplanes[z].productionStage = 0;
			airplanes[z].quantity++;
			showQuantity(z);
		}
		showProductionStage(z);
	}
}

function sell(z) {
	if (airplanes[z].quantity > 0) {
		airplanes[z].quantity -= 1;
		dollars += airplanes[z].price;
		showQuantity(z);
		showValue("dollars");
		budget.thisMonthIncome.sale += airplanes[z].price;
		yearBudget.thisYearIncome.sale += airplanes[z].price;
		clickTrue("quantity"+z);
		clickTrue("price"+z);
	}else clickFalse("quantity"+z);
}

function addEmployee(z) {
	if ((dollars >= employees[z].employmentCost) && (employees[z].maxNumber > employees[z].number)) {
		employees[z].number++;
		dollars -= employees[z].employmentCost;
		budget.thisMonthExpenses.recruitment += employees[z].employmentCost;
		yearBudget.thisYearExpenses.recruitment += employees[z].employmentCost;
		showValue("dollars");
		showEmployeesNumber(z);
		showEmployeesSalary(z);
		if (z == 0) {
			availableWorkers++;
			showValue("workers");
		}
		clickTrue("employee"+z);
	}else {
		clickFalse("employee"+z);
	}
	
}

function removeEmployee(z) {
	if ((z == 0) && (availableWorkers <= 0)) {
		return;
	}


	if ((dollars >= employees[z].employmentCost) && (0 < employees[z].number)) {
		employees[z].number--;
		dollars -= employees[z].employmentCost;
		budget.thisMonthExpenses.recruitment += employees[z].employmentCost;
		yearBudget.thisYearExpenses.recruitment += employees[z].employmentCost;
		showValue("dollars");
		showEmployeesNumber(z);
		showEmployeesSalary(z);
		if (z == 0) {
			availableWorkers--;
			showValue("workers");
		}

		clickTrue("employee"+z);
	}else {
		clickFalse("employee"+z);
	}

}

function titleHireFireCost(z) {
	document.getElementById("addEmployee" + z).title = "hire cost: $" + employees[z].employmentCost;
	document.getElementById("removeEmployee" + z).title = "fire cost: $" + employees[z].employmentCost;
}


function addWorker(z) {
	if (availableWorkers > 0) {
		availableWorkers--;
		airplanes[z].workers++;
		showValue("workers");
		showWorkers(z);
		clickTrue("workers"+z);
	}else clickFalse("workers"+z);
}

function removeWorker(z) {
	if (airplanes[z].workers > 0) {
		availableWorkers++;
		airplanes[z].workers--;
		showValue("workers");
		showWorkers(z);
		clickTrue("workers"+z);
	}else clickFalse("workers"+z);
}

function buyStock(z) {
	const stockCost = parts[z].price * parts[z].stock;
	if (dollars >= stockCost) {
		clickTrue("partsItem"+z);
		dollars -= stockCost;
		showValue("dollars");
		budget.thisMonthExpenses.parts += stockCost;
		yearBudget.thisYearExpenses.parts += stockCost;
		setTimeout(function () {
			let random = Math.floor(Math.random() * 100);
			if (random >= parts[z].risk) {
				availableParts += parts[z].stock;
				showValue("parts");
				creatNewMessage("+"+ parts[z].stock + " parts form " + parts[z].country);
			}
			else{
				creatNewMessage("Delivery failed.<br> Lost: "+ parts[z].stock + " parts",true);
			}
		}, dayTick * parts[z].time);

	}
	else{
		clickFalse("partsItem"+z);
	}

}

function clickFalse(x){
	
	document.getElementById(x).classList.add("click-false");
	setTimeout(function(){
		document.getElementById(x).classList.remove("click-false");
	},500);	
}
function clickTrue(x){

	document.getElementById(x).classList.add("click-true");
	setTimeout(function(){
		document.getElementById(x).classList.remove("click-true");
	},500);	
}

function creatNewMessage(x,y){
	const el = document.createElement("div");
	//el.id = "myDiv";
	el.innerHTML = x;
	el.classList.add("alertsItem");
	if (y)el.classList.add("colorRed");
	//document.getElementById("alerts").appendChild(el);
	document.getElementById("alerts").prepend(el);
	removeNewMessage(el);
}
function removeNewMessage(el){
	setTimeout(function(){ el.remove(); }, 5000);
	
}

function delivery(time, risk, stock) {
	setTimeout()
}

function menu(x) {
	closeMenu();
	document.getElementById(x).classList.remove("unactive");
	document.getElementById("closeMenu").classList.remove("unactive");
}

function closeMenu() {
	document.getElementById("popFunds").classList.add("unactive");
	document.getElementById("popEmployees").classList.add("unactive");
	document.getElementById("popParts").classList.add("unactive");
	document.getElementById("closeMenu").classList.add("unactive");
}

function financesMenu(x) {
	document.getElementById("financesMonths").classList.add("unactive");
	document.getElementById("financesYears").classList.add("unactive");
	document.getElementById("financesBank").classList.add("unactive");
	document.getElementById("financesAwards").classList.add("unactive");
	document.getElementById(x).classList.remove("unactive");
}

function payment() {
	dollars -= totalSalary();
	showValue("dollars");
	budget.thisMonthExpenses.salary += totalSalary();
	yearBudget.thisYearExpenses.salary += totalSalary();
}

function showDate() {
	let MM = date.getMonth() + 1;
	if (MM < 10) MM = "0" + MM;
	let DD = date.getDate();
	if (DD < 10) DD = "0" + DD;
	document.getElementById("date").textContent = date.getFullYear() + "-" + MM + "-" + DD;
}

function showLoans() {
	for (let i = 0; i < loans.length; i++) {
		let cell = document.querySelectorAll("#loan" + i + " > *");
		cell[1].textContent = "$ " + loans[i].amount;
		cell[2].textContent = loans[i].interest + "%";
		cell[3].textContent = loans[i].period + "y";
		cell[5].textContent = loans[i].numberOfInstallments;
	}
}

function takeLoan(x) {
	dollars += loans[x].amount;
	showValue("dollars");
	loans[x].numberOfInstallments = loans[x].period * 12;
	document.querySelector("#loan" + x + " > button + div").textContent = loans[x].numberOfInstallments;
	document.getElementById("takeLoanBtn" + x).textContent = "-";
	document.getElementById("takeLoanBtn" + x).disabled = true;
	clickTrue("loan"+x);
}

function payInstallment() {
	for (let x = 0; x < loans.length; x++) {
		if (loans[x].numberOfInstallments > 0) {
			loans[x].numberOfInstallments--;
			dollars -= loans[x].installment;
			document.querySelector("#loan" + x + " > button + div").textContent = loans[x].numberOfInstallments;
			budget.thisMonthExpenses.interest += loans[x].installment;
			yearBudget.thisYearExpenses.interest += loans[x].installment;
			if (loans[x].numberOfInstallments <= 0) {
				document.getElementById("takeLoanBtn" + x).textContent = "take";
				document.getElementById("takeLoanBtn" + x).disabled = false;
			}
		}
	}
}

function newMonth() {
	for (let x in budget.lastMonthExpenses) {
		budget.agoMonthExpenses[x] = budget.lastMonthExpenses[x];
	}
	for (let x in budget.lastMonthIncome) {
		budget.agoMonthIncome[x] = budget.lastMonthIncome[x];
	}
	for (let x in budget.thisMonthExpenses) {
		budget.lastMonthExpenses[x] = budget.thisMonthExpenses[x];
	}
	for (let x in budget.thisMonthIncome) {
		budget.lastMonthIncome[x] = budget.thisMonthIncome[x];
	}
	for (let x in budget.thisMonthIncome) {
		budget.thisMonthIncome[x] = 0;
	}
	for (let x in budget.thisMonthExpenses) {
		budget.thisMonthExpenses[x] = 0;
	}
	showLastMonthBudget();
	showAgoMonthBudget();
	payInstallment();
}

function newYear() {
	for (let x in yearBudget.lastYearExpenses) {
		yearBudget.agoYearExpenses[x] = yearBudget.lastYearExpenses[x];
	}
	for (let x in yearBudget.lastYearIncome) {
		yearBudget.agoYearIncome[x] = yearBudget.lastYearIncome[x];
	}
	for (let x in yearBudget.thisYearExpenses) {
		yearBudget.lastYearExpenses[x] = yearBudget.thisYearExpenses[x];
	}
	for (let x in yearBudget.thisYearIncome) {
		yearBudget.lastYearIncome[x] = yearBudget.thisYearIncome[x];
	}
	for (let x in yearBudget.thisYearIncome) {
		yearBudget.thisYearIncome[x] = 0;
	}
	for (let x in yearBudget.thisYearExpenses) {
		yearBudget.thisYearExpenses[x] = 0;
	}
	showLastYearBudget();
	showAgoYearBudget();
}

// TIMER	>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
function constructionProgress() {
	if ((date.getDay() == 0) || (date.getDay() == 6)) return;
	progresWork(0, productionForce / 500 * airplanes[0].workers);
	progresWork(1, productionForce / 500 * airplanes[1].workers);
	progresWork(2, productionForce / 500 * airplanes[2].workers);
}

function newDay() {
	date.setTime(date.getTime() + 86400000);
	showDate();
	if (date.getDate() == 1) newMonth();
	if ((date.getDate() == 1) && (date.getMonth() == 0)) newYear();
	if (date.getDay() == 0) payment();

	showThisMonthBudget();
	showThisYearBudget();
}
// TIMER <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
// END FUNCTIONS

// EventsListeners -------------------------------------------------------------------------------------------------------------

document.getElementById("airplane2").addEventListener("click", function () {
	progresWork(2, productionForce)
});
document.getElementById("airplane1").addEventListener("click", function () {
	progresWork(1, productionForce)
});
document.getElementById("airplane0").addEventListener("click", function () {
	progresWork(0, productionForce)
});


document.getElementById("sell0").addEventListener("click", function () {
	sell(0);
});
document.getElementById("sell1").addEventListener("click", function () {
	sell(1);
});
document.getElementById("sell2").addEventListener("click", function () {
	sell(2);
});


document.getElementById("addEmployee0").addEventListener("click", function () {
	addEmployee(0);
});
document.getElementById("addEmployee1").addEventListener("click", function () {
	addEmployee(1);
});
document.getElementById("addEmployee2").addEventListener("click", function () {
	addEmployee(2);
});

document.getElementById("removeEmployee0").addEventListener("click", function () {
	removeEmployee(0);
});
document.getElementById("removeEmployee1").addEventListener("click", function () {
	removeEmployee(1);
});
document.getElementById("removeEmployee2").addEventListener("click", function () {
	removeEmployee(2);
});




document.getElementById("addWorker0").addEventListener("click", function () {
	addWorker(0);
});
document.getElementById("addWorker1").addEventListener("click", function () {
	addWorker(1);
});
document.getElementById("addWorker2").addEventListener("click", function () {
	addWorker(2);
});



document.getElementById("removeWorker0").addEventListener("click", function () {
	removeWorker(0);
});
document.getElementById("removeWorker1").addEventListener("click", function () {
	removeWorker(1);
});

document.getElementById("removeWorker2").addEventListener("click", function () {
	removeWorker(2);
});




document.getElementById("fundsCard").addEventListener("click", function () {
	menu("popFunds");
});
document.getElementById("workersCard").addEventListener("click", function () {
	menu("popEmployees");
});
document.getElementById("partsCard").addEventListener("click", function () {
	menu("popParts");
});

document.getElementById("financesMonthsBtn").addEventListener("click", function () {
	financesMenu("financesMonths");
});
document.getElementById("financesYearsBtn").addEventListener("click", function () {
	financesMenu("financesYears");
});
document.getElementById("financesBankBtn").addEventListener("click", function () {
	financesMenu("financesBank");
});
document.getElementById("financesAwardsBtn").addEventListener("click", function () {
	financesMenu("financesAwards");
});






document.getElementById("closeMenu").addEventListener("click", function () {
	closeMenu();
});

document.getElementById("parts-buy0").addEventListener("click", function () {
	buyStock(0);
});
document.getElementById("parts-buy1").addEventListener("click", function () {
	buyStock(1);
});
document.getElementById("parts-buy2").addEventListener("click", function () {
	buyStock(2);
});

document.getElementById("takeLoanBtn0").addEventListener("click", function () {
	takeLoan(0);
})
document.getElementById("takeLoanBtn1").addEventListener("click", function () {
	takeLoan(1);
})
document.getElementById("takeLoanBtn2").addEventListener("click", function () {
	takeLoan(2);
})
document.getElementById("takeLoanBtn3").addEventListener("click", function () {
	takeLoan(3);
})
// START THE GAME >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
document.body.onload = function () {
	setInterval(constructionProgress, 10);
	setInterval(newDay, dayTick);
	showValue("dollars");
	showValue("workers");
	showValue("parts");
	showEmployeesAll();
	showAirplaneAll();
	titleHireFireCost(0);
	titleHireFireCost(1);
	titleHireFireCost(2);
	showPartsItem(0);
	showPartsItem(1);
	showPartsItem(2);
	showDate();
	showThisMonthBudget();
	showLastMonthBudget();
	showAgoMonthBudget();
	showThisYearBudget();
	showLastYearBudget();
	showAgoYearBudget();
	showLoans();
}
