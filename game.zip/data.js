let dayTick = 50;
let dollars = 5000;
let availableParts = 1000;
let productionForce = 1000;
let date = new Date(1955, 11, 18);

const airplanes = [
	{
		name: "Beoing 737-700",
		parts: 100,
		price: 150000,
		passengers: 110,
		quantity: 0,
		productionStage: 20,
		workers: 0
	},
	{
		name: "Airbus A380-800",
		parts: 200,
		price: 620000,
		passengers: 250,
		quantity: 0,
		productionStage: 30,
		workers: 0
	},
	{
		name: "Airbus A320",
		parts: 65,
		price: 50000,
		passengers: 70,
		quantity: 0,
		productionStage: 0,
		workers: 0
	}
]

const employees = [
	{
		name: "Workers",
		number: 10,
		maxNumber: 20,
		salary: 20,
		employmentCost: 10
	},
	{
		name: "Engineers",
		number: 2,
		maxNumber: 10,
		salary: 42,
		employmentCost: 80
	},
	{
		name: "Human Resources",
		number: 5,
		maxNumber: 10,
		salary: 32,
		employmentCost: 40
	},




]
let availableWorkers = employees[0].number;

const parts = [
	{
		flag: "img/flags/japan.svg",
		country: "Japan",
		company: "Yamato",
		time: 45,
		risk: 10,
		stock: 500,
		price: 25
	},
	{
		flag: "img/flags/india.svg",
		country: "Japan",
		company: "Korma Inc.",
		time: 155,
		risk: 33,
		stock: 1200,
		price: 12
	},
	{
		flag: "img/flags/russia.svg",
		country: "Japan",
		company: "Matrioshka",
		time: 25,
		risk: 50,
		stock: 100,
		price: 7
	}
]


const budget = {
	thisMonthExpenses: {
		salary: 0,
		parts: 0,
		recruitment: 0,
		tax: 0,
		interest: 0,
		other: 0
	},
	thisMonthIncome: {
		sale: 0,
		prizes: 0,
		other: 0
	},
	lastMonthExpenses: {
		salary: 0,
		parts: 0,
		recruitment: 0,
		tax: 0,
		interest: 0,
		other: 0
	},
	lastMonthIncome: {
		sale: 0,
		prizes: 0,
		other: 0
	},
	agoMonthExpenses: {
		salary: 0,
		parts: 0,
		recruitment: 0,
		tax: 0,
		interest: 0,
		other: 0
	},
	agoMonthIncome: {
		sale: 0,
		prizes: 0,
		other: 0
	}

}

const yearBudget = {
	thisYearExpenses: {
		salary: 0,
		parts: 0,
		recruitment: 0,
		tax: 0,
		interest: 0,
		other: 0
	},
	thisYearIncome: {
		sale: 0,
		prizes: 0,
		other: 0
	},
	lastYearExpenses: {
		salary: 0,
		parts: 0,
		recruitment: 0,
		tax: 0,
		interest: 0,
		other: 0
	},
	lastYearIncome: {
		sale: 0,
		prizes: 0,
		other: 0
	},
	agoYearExpenses: {
		salary: 0,
		parts: 0,
		recruitment: 0,
		tax: 0,
		interest: 0,
		other: 0
	},
	agoYearIncome: {
		sale: 0,
		prizes: 0,
		other: 0
	}

}

const loans = [
	{
		amount: 100000,
		interest: 6,
		period: 2,
		installment: 4432,
		numberOfInstallments : 0
	},
	{
		amount: 250000,
		interest: 12,
		period: 4,
		installment: 6583,
		numberOfInstallments : 0
	},
	{
		amount: 500000,
		interest: 18,
		period: 6,
		installment: 11403,
		numberOfInstallments : 0
	},
	{
		amount: 1000000,
		interest: 24,
		period: 8,
		installment: 23513,
		numberOfInstallments : 0
	}
]